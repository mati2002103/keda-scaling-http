# KEDA + RabbitMQ + Celery POC (minikube)

Local sandbox to watch KEDA scale Celery workers based on RabbitMQ queue depth.
Numbers are shrunk to laptop scale (max 10 pods, ~6s tasks) but the mechanics
are identical to staging.

## What you'll see

Enqueue a batch -> queue fills -> KEDA scales workers up (toward max 10) ->
workers drain the queue -> KEDA scales back down to 0.

## Prereqs

- minikube running: `minikube start`
- kubectl, helm installed

## 1. Build the image INTO minikube

minikube has its own Docker daemon. Point your shell at it so the built image
is visible to the cluster without pushing to a registry:

```bash
eval $(minikube docker-env)
cd app
docker build -t celery-poc:local .
cd ..
```

(`imagePullPolicy: IfNotPresent` in the manifests makes k8s use this local image.)

## 2. Install KEDA

```bash
helm repo add kedacore https://kedacore.github.io/charts
helm repo update
helm install keda kedacore/keda --namespace keda --create-namespace --version 2.20.1
```

Wait until KEDA is ready:

```bash
kubectl get pods -n keda
```

## 3. Deploy the POC

```bash
kubectl create namespace keda-poc
kubectl apply -f k8s/01-rabbitmq.yaml
kubectl wait --for=condition=available --timeout=120s deploy/rabbitmq -n keda-poc
kubectl apply -f k8s/02-worker.yaml
kubectl apply -f k8s/03-scaledobject.yaml
```

Check that KEDA registered the scaler (should show READY=True):

```bash
kubectl get scaledobject -n keda-poc
kubectl get hpa -n keda-poc          # KEDA creates an HPA under the hood
```

At this point worker replicas = 0 (queue is empty).

## 4. Fire a batch and watch it scale

In one terminal, watch the pods:

```bash
kubectl get pods -n keda-poc -w
```

In another, enqueue 60 tasks:

```bash
kubectl apply -f k8s/04-producer-job.yaml
```

You should see worker pods appear within ~5-10s (pollingInterval is 5s),
climb toward the max, churn through the tasks, then scale back to 0 about a
minute after the queue empties (cooldownPeriod=60).

To fire another batch:

```bash
kubectl delete job producer -n keda-poc --ignore-not-found
kubectl apply -f k8s/04-producer-job.yaml
```

Change the task count by editing the `"60"` arg in 04-producer-job.yaml.

## 5. Peek at the queue (optional)

```bash
kubectl port-forward -n keda-poc svc/rabbitmq 15672:15672
# open http://localhost:15672  (guest/guest)
```

Watch the `celery` queue depth rise and fall.

## Watching KEDA's decisions

```bash
kubectl describe scaledobject celery-worker-scaler -n keda-poc
kubectl get hpa -n keda-poc -w       # shows current vs target metric
kubectl logs -n keda deploy/keda-operator -f
```

## Mapping back to staging

| POC value            | Staging reality                          |
|----------------------|-------------------------------------------|
| maxReplicaCount: 10  | 120                                       |
| value: 5             | ~15 (1200 msgs / ~80 pods)                |
| task 3-6s            | 2-3 min                                   |
| cooldownPeriod: 60   | 240-300 (must exceed longest task)        |
| concurrency 4        | 4 (keep prefetch == concurrency)          |

Key carry-overs to staging:
- `mode: QueueLength` (batchy traffic, not a steady stream).
- `task_acks_late=True` + `terminationGracePeriodSeconds` > task time, so
  scale-down never loses an in-flight task.
- `cooldownPeriod` strictly greater than your longest task.
- Consider whether to scale on `ready` vs `ready+unacked`; with long tasks,
  unacked messages inflate the backlog and can keep pods up too long.

## Teardown

```bash
kubectl delete namespace keda-poc
helm uninstall keda -n keda
```
