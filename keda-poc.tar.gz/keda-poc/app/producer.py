import os
import sys
from celery import Celery

BROKER_URL = os.environ.get("CELERY_BROKER_URL", "amqp://guest:guest@rabbitmq:5672//")
app = Celery("poc", broker=BROKER_URL)

# Number of tasks to enqueue. Default 60 -> enough to push KEDA toward its max
# of 10 pods with queueLength target of 5 (60/5 = 12, capped at 10).
count = int(sys.argv[1]) if len(sys.argv) > 1 else 60

for i in range(count):
    app.send_task("poc.process", args=[i])

print(f"Enqueued {count} tasks to {BROKER_URL}")
