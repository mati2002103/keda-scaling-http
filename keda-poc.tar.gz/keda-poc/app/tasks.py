import os
import time
import random
from celery import Celery

# Broker URL pulled from env so the same image works locally and in-cluster.
BROKER_URL = os.environ.get("CELERY_BROKER_URL", "amqp://guest:guest@rabbitmq:5672//")

app = Celery("poc", broker=BROKER_URL)

# Mirror the staging behaviour: each worker process handles a few tasks
# concurrently, and tasks are long-running. We ack late so that if a worker
# pod is killed mid-task (e.g. during scale-down), the task goes back to the
# queue instead of being lost.
app.conf.update(
    task_acks_late=True,
    worker_prefetch_multiplier=1,   # don't let one worker hoard the backlog
    task_reject_on_worker_lost=True,
)


@app.task(name="poc.process")
def process(n):
    # Simulate a long task (scaled down from 2-3 min to a few seconds for a
    # laptop-friendly demo). Bump this up if you want to watch scaling longer.
    duration = random.uniform(3, 6)
    time.sleep(duration)
    return {"n": n, "slept": round(duration, 2)}
